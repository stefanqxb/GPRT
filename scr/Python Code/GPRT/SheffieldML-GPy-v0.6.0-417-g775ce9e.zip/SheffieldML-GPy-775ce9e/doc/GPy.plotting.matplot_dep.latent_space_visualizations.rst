GPy.plotting.matplot_dep.latent_space_visualizations package
============================================================

Subpackages
-----------

.. toctree::

    GPy.plotting.matplot_dep.latent_space_visualizations.controllers

Module contents
---------------

.. automodule:: GPy.plotting.matplot_dep.latent_space_visualizations
    :members:
    :undoc-members:
    :show-inheritance:
