GPy.inference.optimization package
==================================

Submodules
----------

GPy.inference.optimization.conjugate_gradient_descent module
------------------------------------------------------------

.. automodule:: GPy.inference.optimization.conjugate_gradient_descent
    :members:
    :undoc-members:
    :show-inheritance:

GPy.inference.optimization.gradient_descent_update_rules module
---------------------------------------------------------------

.. automodule:: GPy.inference.optimization.gradient_descent_update_rules
    :members:
    :undoc-members:
    :show-inheritance:

GPy.inference.optimization.optimization module
----------------------------------------------

.. automodule:: GPy.inference.optimization.optimization
    :members:
    :undoc-members:
    :show-inheritance:

GPy.inference.optimization.scg module
-------------------------------------

.. automodule:: GPy.inference.optimization.scg
    :members:
    :undoc-members:
    :show-inheritance:

GPy.inference.optimization.sgd module
-------------------------------------

.. automodule:: GPy.inference.optimization.sgd
    :members:
    :undoc-members:
    :show-inheritance:

GPy.inference.optimization.stochastics module
---------------------------------------------

.. automodule:: GPy.inference.optimization.stochastics
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: GPy.inference.optimization
    :members:
    :undoc-members:
    :show-inheritance:
