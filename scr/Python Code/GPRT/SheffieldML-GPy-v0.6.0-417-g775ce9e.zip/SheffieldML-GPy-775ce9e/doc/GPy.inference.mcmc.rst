GPy.inference.mcmc package
==========================

Submodules
----------

GPy.inference.mcmc.hmc module
-----------------------------

.. automodule:: GPy.inference.mcmc.hmc
    :members:
    :undoc-members:
    :show-inheritance:

GPy.inference.mcmc.samplers module
----------------------------------

.. automodule:: GPy.inference.mcmc.samplers
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: GPy.inference.mcmc
    :members:
    :undoc-members:
    :show-inheritance:
