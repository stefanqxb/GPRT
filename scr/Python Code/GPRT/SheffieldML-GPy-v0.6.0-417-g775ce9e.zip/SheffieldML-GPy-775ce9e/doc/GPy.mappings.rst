GPy.mappings package
====================

Submodules
----------

GPy.mappings.additive module
----------------------------

.. automodule:: GPy.mappings.additive
    :members:
    :undoc-members:
    :show-inheritance:

GPy.mappings.kernel module
--------------------------

.. automodule:: GPy.mappings.kernel
    :members:
    :undoc-members:
    :show-inheritance:

GPy.mappings.linear module
--------------------------

.. automodule:: GPy.mappings.linear
    :members:
    :undoc-members:
    :show-inheritance:

GPy.mappings.mlp module
-----------------------

.. automodule:: GPy.mappings.mlp
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: GPy.mappings
    :members:
    :undoc-members:
    :show-inheritance:
