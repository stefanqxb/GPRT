GPy.kern package
================

Subpackages
-----------

.. toctree::

    GPy.kern._src

Module contents
---------------

.. automodule:: GPy.kern
    :members:
    :undoc-members:
    :show-inheritance:
