GPy.plotting.matplot_dep package
================================

Subpackages
-----------

.. toctree::

    GPy.plotting.matplot_dep.latent_space_visualizations

Submodules
----------

GPy.plotting.matplot_dep.Tango module
-------------------------------------

.. automodule:: GPy.plotting.matplot_dep.Tango
    :members:
    :undoc-members:
    :show-inheritance:

GPy.plotting.matplot_dep.base_plots module
------------------------------------------

.. automodule:: GPy.plotting.matplot_dep.base_plots
    :members:
    :undoc-members:
    :show-inheritance:

GPy.plotting.matplot_dep.dim_reduction_plots module
---------------------------------------------------

.. automodule:: GPy.plotting.matplot_dep.dim_reduction_plots
    :members:
    :undoc-members:
    :show-inheritance:

GPy.plotting.matplot_dep.img_plots module
-----------------------------------------

.. automodule:: GPy.plotting.matplot_dep.img_plots
    :members:
    :undoc-members:
    :show-inheritance:

GPy.plotting.matplot_dep.inference_plots module
-----------------------------------------------

.. automodule:: GPy.plotting.matplot_dep.inference_plots
    :members:
    :undoc-members:
    :show-inheritance:

GPy.plotting.matplot_dep.kernel_plots module
--------------------------------------------

.. automodule:: GPy.plotting.matplot_dep.kernel_plots
    :members:
    :undoc-members:
    :show-inheritance:

GPy.plotting.matplot_dep.mapping_plots module
---------------------------------------------

.. automodule:: GPy.plotting.matplot_dep.mapping_plots
    :members:
    :undoc-members:
    :show-inheritance:

GPy.plotting.matplot_dep.maps module
------------------------------------

.. automodule:: GPy.plotting.matplot_dep.maps
    :members:
    :undoc-members:
    :show-inheritance:

GPy.plotting.matplot_dep.models_plots module
--------------------------------------------

.. automodule:: GPy.plotting.matplot_dep.models_plots
    :members:
    :undoc-members:
    :show-inheritance:

GPy.plotting.matplot_dep.netpbmfile module
------------------------------------------

.. automodule:: GPy.plotting.matplot_dep.netpbmfile
    :members:
    :undoc-members:
    :show-inheritance:

GPy.plotting.matplot_dep.priors_plots module
--------------------------------------------

.. automodule:: GPy.plotting.matplot_dep.priors_plots
    :members:
    :undoc-members:
    :show-inheritance:

GPy.plotting.matplot_dep.ssgplvm module
---------------------------------------

.. automodule:: GPy.plotting.matplot_dep.ssgplvm
    :members:
    :undoc-members:
    :show-inheritance:

GPy.plotting.matplot_dep.svig_plots module
------------------------------------------

.. automodule:: GPy.plotting.matplot_dep.svig_plots
    :members:
    :undoc-members:
    :show-inheritance:

GPy.plotting.matplot_dep.variational_plots module
-------------------------------------------------

.. automodule:: GPy.plotting.matplot_dep.variational_plots
    :members:
    :undoc-members:
    :show-inheritance:

GPy.plotting.matplot_dep.visualize module
-----------------------------------------

.. automodule:: GPy.plotting.matplot_dep.visualize
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: GPy.plotting.matplot_dep
    :members:
    :undoc-members:
    :show-inheritance:
