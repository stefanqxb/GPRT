GPy.examples package
====================

Submodules
----------

GPy.examples.classification module
----------------------------------

.. automodule:: GPy.examples.classification
    :members:
    :undoc-members:
    :show-inheritance:

GPy.examples.coreg_example module
---------------------------------

.. automodule:: GPy.examples.coreg_example
    :members:
    :undoc-members:
    :show-inheritance:

GPy.examples.dimensionality_reduction module
--------------------------------------------

.. automodule:: GPy.examples.dimensionality_reduction
    :members:
    :undoc-members:
    :show-inheritance:

GPy.examples.non_gaussian module
--------------------------------

.. automodule:: GPy.examples.non_gaussian
    :members:
    :undoc-members:
    :show-inheritance:

GPy.examples.regression module
------------------------------

.. automodule:: GPy.examples.regression
    :members:
    :undoc-members:
    :show-inheritance:

GPy.examples.stochastic module
------------------------------

.. automodule:: GPy.examples.stochastic
    :members:
    :undoc-members:
    :show-inheritance:

GPy.examples.tutorials module
-----------------------------

.. automodule:: GPy.examples.tutorials
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: GPy.examples
    :members:
    :undoc-members:
    :show-inheritance:
