GPy.testing package
===================

Submodules
----------

GPy.testing.examples_tests module
---------------------------------

.. automodule:: GPy.testing.examples_tests
    :members:
    :undoc-members:
    :show-inheritance:

GPy.testing.fitc module
-----------------------

.. automodule:: GPy.testing.fitc
    :members:
    :undoc-members:
    :show-inheritance:

GPy.testing.index_operations_tests module
-----------------------------------------

.. automodule:: GPy.testing.index_operations_tests
    :members:
    :undoc-members:
    :show-inheritance:

GPy.testing.inference_tests module
----------------------------------

.. automodule:: GPy.testing.inference_tests
    :members:
    :undoc-members:
    :show-inheritance:

GPy.testing.kernel_tests module
-------------------------------

.. automodule:: GPy.testing.kernel_tests
    :members:
    :undoc-members:
    :show-inheritance:

GPy.testing.likelihood_tests module
-----------------------------------

.. automodule:: GPy.testing.likelihood_tests
    :members:
    :undoc-members:
    :show-inheritance:

GPy.testing.model_tests module
------------------------------

.. automodule:: GPy.testing.model_tests
    :members:
    :undoc-members:
    :show-inheritance:

GPy.testing.observable_tests module
-----------------------------------

.. automodule:: GPy.testing.observable_tests
    :members:
    :undoc-members:
    :show-inheritance:

GPy.testing.parameterized_tests module
--------------------------------------

.. automodule:: GPy.testing.parameterized_tests
    :members:
    :undoc-members:
    :show-inheritance:

GPy.testing.pickle_tests module
-------------------------------

.. automodule:: GPy.testing.pickle_tests
    :members:
    :undoc-members:
    :show-inheritance:

GPy.testing.prior_tests module
------------------------------

.. automodule:: GPy.testing.prior_tests
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: GPy.testing
    :members:
    :undoc-members:
    :show-inheritance:
