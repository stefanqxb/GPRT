GPy.plotting package
====================

Subpackages
-----------

.. toctree::

    GPy.plotting.matplot_dep

Module contents
---------------

.. automodule:: GPy.plotting
    :members:
    :undoc-members:
    :show-inheritance:
