GPy.inference package
=====================

Subpackages
-----------

.. toctree::

    GPy.inference.latent_function_inference
    GPy.inference.mcmc
    GPy.inference.optimization

Module contents
---------------

.. automodule:: GPy.inference
    :members:
    :undoc-members:
    :show-inheritance:
