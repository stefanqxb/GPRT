GPy package
===========

Subpackages
-----------

.. toctree::

    GPy.core
    GPy.examples
    GPy.inference
    GPy.kern
    GPy.likelihoods
    GPy.mappings
    GPy.models
    GPy.plotting
    GPy.testing
    GPy.util

Module contents
---------------

.. automodule:: GPy
    :members:
    :undoc-members:
    :show-inheritance:
