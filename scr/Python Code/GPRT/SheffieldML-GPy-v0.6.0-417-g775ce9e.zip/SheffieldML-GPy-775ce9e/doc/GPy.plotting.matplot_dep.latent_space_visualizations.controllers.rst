GPy.plotting.matplot_dep.latent_space_visualizations.controllers package
========================================================================

Submodules
----------

GPy.plotting.matplot_dep.latent_space_visualizations.controllers.axis_event_controller module
---------------------------------------------------------------------------------------------

.. automodule:: GPy.plotting.matplot_dep.latent_space_visualizations.controllers.axis_event_controller
    :members:
    :undoc-members:
    :show-inheritance:

GPy.plotting.matplot_dep.latent_space_visualizations.controllers.imshow_controller module
-----------------------------------------------------------------------------------------

.. automodule:: GPy.plotting.matplot_dep.latent_space_visualizations.controllers.imshow_controller
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: GPy.plotting.matplot_dep.latent_space_visualizations.controllers
    :members:
    :undoc-members:
    :show-inheritance:
